
let changeIcon= Function ('icon'){
    icon.classList.toggle('fa-times')
}